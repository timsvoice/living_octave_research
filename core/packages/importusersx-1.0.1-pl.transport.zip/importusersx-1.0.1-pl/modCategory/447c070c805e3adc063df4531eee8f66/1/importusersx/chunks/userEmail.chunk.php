<p>Hello,</p>

    <p>An account was created for you in [[+sname]]. Here are your login details :</p>

    <p><strong>Username:</strong> [[+alias]]<br />
    <strong>Password:</strong> [[+password]]</p>

    <p>Once you log into [[+sname]] at [[+surl]], you can change your password.</p>